import React, { useState } from 'react';
import { Send, Menu, MessageSquare } from 'lucide-react';

// Predefined questions
const PRESET_QUESTIONS = [
  "Top 5 vendors by average rating",
  "Plot number of reviews by vendor",
  "Which station has the highest review count?",
  "List stations with below average rating"
];

function App() {
  const [input, setInput] = useState('');
  const [responses, setResponses] = useState<Array<{question: string, answer: string}>>([]);
  const [sidebarOpen, setSidebarOpen] = useState(true);

  const handleSubmit = async (question: string) => {
    // TODO: Replace with actual API call
    const mockResponse = `Sample response for: ${question}`;
    setResponses(prev => [...prev, { question, answer: mockResponse }]);
    setInput('');
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <div className={`${sidebarOpen ? 'w-80' : 'w-0'} bg-white border-r border-gray-200 transition-all duration-300 overflow-hidden`}>
        <div className="p-6">
          <h2 className="text-lg font-semibold text-gray-800 mb-4 flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Suggested Questions
          </h2>
          <div className="space-y-2">
            {PRESET_QUESTIONS.map((question, index) => (
              <button
                key={index}
                onClick={() => handleSubmit(question)}
                className="w-full text-left p-3 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors text-gray-700 text-sm"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Header */}
        <header className="bg-white border-b border-gray-200 p-4">
          <button
            onClick={() => setSidebarOpen(!sidebarOpen)}
            className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
          >
            <Menu className="w-5 h-5 text-gray-600" />
          </button>
        </header>

        {/* Chat Area */}
        <div className="flex-1 overflow-auto p-6">
          {responses.map((response, index) => (
            <div key={index} className="mb-6">
              <div className="bg-blue-50 p-4 rounded-t-lg">
                <p className="text-blue-800 font-medium">{response.question}</p>
              </div>
              <div className="bg-white p-4 rounded-b-lg border border-gray-200">
                <p className="text-gray-700">{response.answer}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Input Area */}
        <div className="border-t border-gray-200 bg-white p-4">
          <form 
            onSubmit={(e) => {
              e.preventDefault();
              if (input.trim()) handleSubmit(input.trim());
            }}
            className="flex gap-2"
          >
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ask a question..."
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Send className="w-4 h-4" />
              Send
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

export default App;